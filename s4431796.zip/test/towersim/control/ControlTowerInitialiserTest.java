package towersim.control;

import org.junit.Before;
import org.junit.Test;
import towersim.aircraft.Aircraft;
import towersim.aircraft.PassengerAircraft;

import static org.junit.Assert.*;

public class ControlTowerInitialiserTest {

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void loadAircraft() {

    }

    @Test
    public void readAircraft() {

    }

    @Test
    public void readTaskList() {

    }
}